package att.com.mx.appd.utils.beans;

public class DatabaseNodeVO {
	private int id;
	private String name;
	private int configId;
	private String host;
	private int port;
	private String ipAddress;
	private String uniqueHostId;
	
	public DatabaseNodeVO() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getUniqueHostId() {
		return uniqueHostId;
	}

	public void setUniqueHostId(String uniqueHostId) {
		this.uniqueHostId = uniqueHostId;
	}
	
	
}
