package att.com.mx.appd.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;

public class RestAPIUtility {

	private BufferedReader bufferedReader = null;
	private InputStreamReader inputStreamReader = null;
	private HttpsURLConnection httpsURLConnection = null;
	//private Gson gson = null;
	
	private URL url = null;
	
	public String getRestfulResponse (String strUrl,String access_token) {
		StringBuilder strResponse = new StringBuilder();
		CertificateUtil certificateUtil=null;
		try {
			certificateUtil =new CertificateUtil();
			url = new URL(strUrl);
			certificateUtil.validate();
			httpsURLConnection = (HttpsURLConnection) url.openConnection();
			httpsURLConnection.setReadTimeout(30000);
			httpsURLConnection.setConnectTimeout(30000);
			httpsURLConnection.setRequestMethod("GET");
			httpsURLConnection.setRequestProperty("Accept", "application/json");
			
			
			httpsURLConnection.setRequestProperty("Authorization","Bearer "+access_token);
			inputStreamReader = new InputStreamReader(httpsURLConnection.getInputStream(), "UTF-8");
			bufferedReader = new BufferedReader(inputStreamReader);
			for (int c; (c = bufferedReader.read()) >= 0;) {
				strResponse.append((char) c);
			}
			bufferedReader.close();
			inputStreamReader.close();
			httpsURLConnection.disconnect();
			httpsURLConnection = null;
			url = null;
			certificateUtil=null;
		} catch (SocketTimeoutException ste) {
			System.out.println("Error" + ste.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}

		} catch (UnknownHostException uhe) {
			System.out.println("Error" + uhe.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} catch (Exception exc) {
			System.out.println("Error" + exc.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		}
		return strResponse.toString();
	}
	
	public String getRestfulResponseByToken (String strUrl,String token) {
		StringBuilder strResponse = new StringBuilder();
		CertificateUtil certificateUtil=null;
		try {
			certificateUtil =new CertificateUtil();
			url = new URL(strUrl);
			certificateUtil.validate();
			httpsURLConnection = (HttpsURLConnection) url.openConnection();
			httpsURLConnection.setReadTimeout(30000);
			httpsURLConnection.setConnectTimeout(30000);
			httpsURLConnection.setRequestMethod("GET");
			httpsURLConnection.setRequestProperty("Accept", "application/json");
			
			
			httpsURLConnection.setRequestProperty("Authorization","Bearer "+token);
			inputStreamReader = new InputStreamReader(httpsURLConnection.getInputStream(), "UTF-8");
			bufferedReader = new BufferedReader(inputStreamReader);
			for (int c; (c = bufferedReader.read()) >= 0;) {
				strResponse.append((char) c);
			}
			bufferedReader.close();
			inputStreamReader.close();
			httpsURLConnection.disconnect();
			httpsURLConnection = null;
			url = null;
			certificateUtil=null;
		} catch (SocketTimeoutException ste) {
			System.out.println("Error" + ste.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}

		} catch (UnknownHostException uhe) {
			System.out.println("Error" + uhe.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} catch (Exception exc) {
			System.out.println("Error" + exc.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		}
		return strResponse.toString();
	}
	
	public String createMethod (String strUrl, String postData) {
		StringBuilder strResponse = new StringBuilder();
		CertificateUtil certificateUtil=null;
		try {
			
	        byte[] postDataBytes = postData.getBytes("UTF-8");

			certificateUtil =new CertificateUtil();
			url = new URL(strUrl);
			certificateUtil.validate();
			httpsURLConnection = (HttpsURLConnection) url.openConnection();
			httpsURLConnection.setReadTimeout(30000);
			httpsURLConnection.setConnectTimeout(30000);
			httpsURLConnection.setRequestMethod("POST");
			httpsURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			
			httpsURLConnection.setRequestProperty("Content-Length",
	                String.valueOf(postDataBytes.length));
			
			httpsURLConnection.setDoOutput(true);
			OutputStream outputStream =httpsURLConnection.getOutputStream();
			outputStream.write(postDataBytes);
			outputStream.flush();
			outputStream.close();
				inputStreamReader=	new InputStreamReader(httpsURLConnection.getInputStream(),"UTF-8");
				
				bufferedReader = new BufferedReader(inputStreamReader);
				for (int c; (c = bufferedReader.read()) >= 0;) {
					strResponse.append((char) c);
				}
				
				bufferedReader.close();
				inputStreamReader.close();
			httpsURLConnection.disconnect();
			httpsURLConnection = null;
			url = null;
			certificateUtil=null;
			System.out.println(strResponse.toString());
		} catch (SocketTimeoutException ste) {
			System.out.println("Error a " + ste.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}

		} catch (UnknownHostException uhe) {
			System.out.println("Error b " + uhe.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} catch (Exception exc) {
			System.out.println("Error c " + exc.getMessage());
			exc.getLocalizedMessage();
			exc.printStackTrace();
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		}
		return strResponse.toString();
	}
	
	public String getAllDBStatus (String strUrl,String token,String body) {
		 
		StringBuilder strResponse = new StringBuilder();
		CertificateUtil certificateUtil=null;
		try {
			  byte[] postDataBytes = body.getBytes("UTF-8");
			certificateUtil =new CertificateUtil();
			url = new URL(strUrl);
			certificateUtil.validate();
			httpsURLConnection = (HttpsURLConnection) url.openConnection();
			httpsURLConnection.setReadTimeout(30000);
			httpsURLConnection.setConnectTimeout(30000);
			httpsURLConnection.setRequestMethod("POST");
			httpsURLConnection.setRequestProperty("Content-Type", "application/json");
			httpsURLConnection.setRequestProperty("Content-Length",
	                String.valueOf(postDataBytes.length));
		
			
			
			httpsURLConnection.setRequestProperty("Authorization","Bearer "+token);
			
			httpsURLConnection.setDoOutput(true);
			OutputStream outputStream =httpsURLConnection.getOutputStream();
			outputStream.write(postDataBytes);
			outputStream.flush();
			outputStream.close();
				inputStreamReader=	new InputStreamReader(httpsURLConnection.getInputStream(),"UTF-8");
				
				bufferedReader = new BufferedReader(inputStreamReader);
				for (int c; (c = bufferedReader.read()) >= 0;) {
					strResponse.append((char) c);
				}
				
				bufferedReader.close();
				inputStreamReader.close();
			httpsURLConnection.disconnect();
			httpsURLConnection = null;
			url = null;
			certificateUtil=null;
			System.out.println(strResponse.toString());
		} catch (SocketTimeoutException ste) {
			System.out.println("Error" + ste.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}

		} catch (UnknownHostException uhe) {
			System.out.println("Error" + uhe.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} catch (Exception exc) {
			System.out.println("Error" + exc.getMessage());
			strResponse = new StringBuilder();
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		} finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				bufferedReader = null;
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				inputStreamReader = null;
				if (httpsURLConnection != null) {
					httpsURLConnection.disconnect();
				}
				httpsURLConnection = null;
				url = null;
				certificateUtil=null;
			} catch (Exception exception) {

			}
		}
		return strResponse.toString();
	}
	
	
	
}
