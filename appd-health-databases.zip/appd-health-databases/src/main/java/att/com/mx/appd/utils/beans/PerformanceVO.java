package att.com.mx.appd.utils.beans;

public class PerformanceVO {
	private String performanceState;
	private String collectorStatus;
	private int configId;
    private String name;
    public PerformanceVO() {
    	
    }
	public String getPerformanceState() {
		return performanceState;
	}
	public void setPerformanceState(String performanceState) {
		this.performanceState = performanceState;
	}
	public String getCollectorStatus() {
		return collectorStatus;
	}
	public void setCollectorStatus(String collectorStatus) {
		this.collectorStatus = collectorStatus;
	}
	public int getConfigId() {
		return configId;
	}
	public void setConfigId(int configId) {
		this.configId = configId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
    
    
}
