package att.com.mx.appd.utils.beans.alerts;

public class TriggeredEntityDefinition {
	private String entityType;
	private String name;
	private int entityId;
	
	public TriggeredEntityDefinition() {
		
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEntityId() {
		return entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}
	
	
}
