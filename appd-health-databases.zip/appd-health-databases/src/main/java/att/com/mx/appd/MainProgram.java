package att.com.mx.appd;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import att.com.mx.appd.service.AppDynamicsService;
import att.com.mx.appd.service.AppDynamicsServiceImpl;

public class MainProgram {
	public static Logger LOG = LogManager.getLogger(MainProgram.class.getName());

	public static void main(String args[]) {
		AppDynamicsService appDynamicsService = null;
		appDynamicsService = new AppDynamicsServiceImpl();
		//appDynamicsService.generateTemporaryAccessToken();
		appDynamicsService.getDatabaseAlarms();
		appDynamicsService = null;

	}

}
