package att.com.mx.appd.utils.beans;

import java.util.List;

public class GeneralVO {
	private List<PerformanceVO> data;
	public GeneralVO(){
		
	}
	public List<PerformanceVO> getData() {
		return data;
	}
	public void setData(List<PerformanceVO> data) {
		this.data = data;
	}
	
	
}
