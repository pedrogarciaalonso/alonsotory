package att.com.mx.appd.utils.beans.alerts;

public class DatabaseAlertVO {
	private String deepLinkUrl;
	private String severity;
	private TriggeredEntityDefinition triggeredEntityDefinition;
    private long startTimeInMillis;
    private int detectedTimeInMillis;
    private long endTimeInMillis;
    private String name;
    private String description;
    private int id;
    private AffectedEntityDefinition affectedEntityDefinition;
    private String incidentStatus;
    
    public DatabaseAlertVO() {
    	
    }

	public String getDeepLinkUrl() {
		return deepLinkUrl;
	}

	public void setDeepLinkUrl(String deepLinkUrl) {
		this.deepLinkUrl = deepLinkUrl;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public TriggeredEntityDefinition getTriggeredEntityDefinition() {
		return triggeredEntityDefinition;
	}

	public void setTriggeredEntityDefinition(TriggeredEntityDefinition triggeredEntityDefinition) {
		this.triggeredEntityDefinition = triggeredEntityDefinition;
	}

	public long getStartTimeInMillis() {
		return startTimeInMillis;
	}

	public void setStartTimeInMillis(long startTimeInMillis) {
		this.startTimeInMillis = startTimeInMillis;
	}

	public int getDetectedTimeInMillis() {
		return detectedTimeInMillis;
	}

	public void setDetectedTimeInMillis(int detectedTimeInMillis) {
		this.detectedTimeInMillis = detectedTimeInMillis;
	}

	public long getEndTimeInMillis() {
		return endTimeInMillis;
	}

	public void setEndTimeInMillis(long endTimeInMillis) {
		this.endTimeInMillis = endTimeInMillis;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AffectedEntityDefinition getAffectedEntityDefinition() {
		return affectedEntityDefinition;
	}

	public void setAffectedEntityDefinition(AffectedEntityDefinition affectedEntityDefinition) {
		this.affectedEntityDefinition = affectedEntityDefinition;
	}

	public String getIncidentStatus() {
		return incidentStatus;
	}

	public void setIncidentStatus(String incidentStatus) {
		this.incidentStatus = incidentStatus;
	}
    
    
}
