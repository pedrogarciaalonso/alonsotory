package att.com.mx.appd.service;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import att.com.mx.appd.MainProgram;
import att.com.mx.appd.utils.RestAPIUtility;
import att.com.mx.appd.utils.beans.CollectorVO;
import att.com.mx.appd.utils.beans.DatabaseNodeVO;
import att.com.mx.appd.utils.beans.GeneralVO;
import att.com.mx.appd.utils.beans.PerformanceVO;
import att.com.mx.appd.utils.beans.TokenVO;
import att.com.mx.appd.utils.beans.UnixTimeVO;
import att.com.mx.appd.utils.beans.alerts.DatabaseAlertVO;

/**
 * 
 * @author pg115r
 *
 */
public class AppDynamicsServiceImpl implements AppDynamicsService {
	public static Logger LOG = LogManager.getLogger(AppDynamicsServiceImpl.class.getName());
	
	public static final String ACCESS_TOKEN_24_HOURS = "AQUI VA EL TOKEN";
	public static final String APPD_CONTROLLER = "https://attmexico-prod.saas.appdynamics.com/controller";
	public static final String CLIENT_ID = "xyzapikey@cuentaxyz";// lo proporciona Mexico IT AppDynamics
	public static final String CLIENT_SECRET = "aquivaelclientsecret";// lo proporciona Mexico IT AppDynamics

	public List<Integer> getAllCollectors() {
		LOG.info("Metodo getAllCollectors");
		List<Integer> ids = new ArrayList<Integer>();
		RestAPIUtility apiRestUtility = null;
		Gson gson = null;

		apiRestUtility = new RestAPIUtility();

		String url = APPD_CONTROLLER + "/rest/databases/collectors";

		String json = apiRestUtility.getRestfulResponse(url, ACCESS_TOKEN_24_HOURS);
		LOG.info("Obteniendo el documento JSON:"+json);
		gson = new Gson();
		List<CollectorVO> collectors = null;
		collectors = gson.fromJson(json, new TypeToken<List<CollectorVO>>() {
		}.getType());

		for (CollectorVO collectorVO : collectors) {
			ids.add(collectorVO.getConfig().getId());
		}

		apiRestUtility = null;

		apiRestUtility = null;
		gson = null;
		json = null;
		return ids;
	}

	public List<DatabaseNodeVO> getDatabaseServers() {
		LOG.info("Metodo getDatabaseServers");
		List<DatabaseNodeVO> databases = null;
		RestAPIUtility apiRestUtility = null;
		Gson gson = null;

		apiRestUtility = new RestAPIUtility();

		String url = APPD_CONTROLLER + "/rest/databases/servers";
		gson = new Gson();
		String json = apiRestUtility.getRestfulResponseByToken(url, ACCESS_TOKEN_24_HOURS);
		LOG.info("Obteniendo el documento JSON:"+json);
		
		databases = gson.fromJson(json, new TypeToken<List<DatabaseNodeVO>>() {
		}.getType());

		apiRestUtility = null;

		apiRestUtility = null;
		gson = null;
		json = null;
		return databases;
	}

	public void generateTemporaryAccessToken() {
		LOG.info("Metodo generateTemporaryAccessToken");
		RestAPIUtility apiRestUtility = null;
		Gson gson = null;

		apiRestUtility = new RestAPIUtility();

		String url = APPD_CONTROLLER + "/api/oauth/access_token";

		Map<String, String> parameters = new HashMap<String, String>();

		parameters.put("grant_type", "client_credentials");
		parameters.put("client_id", CLIENT_ID);
		parameters.put("client_secret", CLIENT_SECRET);
		StringBuilder postData = new StringBuilder();

		try {
			for (Map.Entry<String, String> param : parameters.entrySet()) {
				if (postData.length() != 0)
					postData.append('&');

				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));

				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
		gson = new Gson();
		String json = apiRestUtility.createMethod(url, postData.toString());
		TokenVO tokenVO = gson.fromJson(json, TokenVO.class);
		LOG.info("Token obtenido:"+tokenVO.getAccess_token());
		LOG.info("Expira en:"+tokenVO.getExpires_in());
	}

	public String getAllDBVisibility(String configIds, long startTime, long endTime) {
		LOG.info("Metodo getAllDBVisibility");
		String json = null;
		RestAPIUtility apiRestUtility = null;
		apiRestUtility = new RestAPIUtility();

		String url = APPD_CONTROLLER + "/databasesui/databases/list/data?maxDataPointsPerMetric=1440";
		String body = "{    \"requestFilter\": " + configIds
				+ ",    \"resultColumns\": [        \"HEALTH\",        \"QUERIES\",        \"QUERIES_TREND\",        \"TIME_SPENT\",        \"TIME_SPENT_TREND\",        \"CPU\",        \"CPU_TREND\"    ],    \"offset\": 0,    \"limit\": -1,    \"searchFilters\": [],    \"columnSorts\": [        {            \"column\": \"TIME_SPENT\",            \"direction\": \"DESC\"        }    ],    \"timeRangeStart\": "
				+ startTime + ",    \"timeRangeEnd\": " + endTime + "}";
		json = apiRestUtility.getAllDBStatus(url, ACCESS_TOKEN_24_HOURS, body);
		LOG.info("Obteniendo el documento JSON:"+json);
		return json;
	}

	public List<DatabaseAlertVO> getHealthRulesViolations(int collectorId) {
		List<DatabaseAlertVO> alerts = null;
		RestAPIUtility apiRestUtility = null;
		Gson gson = null;

		apiRestUtility = new RestAPIUtility();

		String url = APPD_CONTROLLER + "/rest/databases/servers/healthrule-violations/" + collectorId
				+ "?time-range-type=BEFORE_NOW&duration-in-mins=15&output=JSON";
		String json = apiRestUtility.getRestfulResponse(url, ACCESS_TOKEN_24_HOURS);
		LOG.info("Obteniendo el documento JSON:"+json);
		gson = new Gson();
		alerts = gson.fromJson(json, new TypeToken<List<DatabaseAlertVO>>() {
		}.getType());

		apiRestUtility = null;
		gson = null;
		json = null;

		return alerts;
	}

	public UnixTimeVO getUnixDatetime() {
		UnixTimeVO unixTimeVo = null;

		unixTimeVo = new UnixTimeVO();
		long epoch = System.currentTimeMillis();

		Calendar calendar = Calendar.getInstance();
		// Remove 15 minutes to current date
		calendar.add(Calendar.MINUTE, -15);

		unixTimeVo.setStartTime(calendar.getTimeInMillis());
		unixTimeVo.setEndTime(epoch);
		return unixTimeVo;
	}

	public void getDatabaseAlarms() {
		/**
		 * Es para la obtenci�n de configid para generar un catalogo en un tabla
		 */
		List<Integer> ids = null;

		ids = getAllCollectors();

		/**
		 * Es para obtener el estado cada collector Se pasan como par�metros los
		 * configids
		 * 
		 * 
		 * performanceState collectorStatus configId,
		 */
		UnixTimeVO unixTimeVO = getUnixDatetime();// obtiene fechas formato Unix los �ltimos 15 minutos

		Gson gson = new Gson();
		String configIds = gson.toJson(ids, ArrayList.class);

		List<PerformanceVO> degradedDatabases = null;

		String generalState = getAllDBVisibility(configIds, unixTimeVO.getStartTime(), unixTimeVO.getEndTime());
		GeneralVO generalVO = gson.fromJson(generalState, GeneralVO.class);
		if (generalVO != null) {
			degradedDatabases = new ArrayList<PerformanceVO>();
			for (PerformanceVO performanceVO : generalVO.getData()) {
				if (performanceVO != null) {
					if ((performanceVO.getPerformanceState() != null
							&& !performanceVO.getPerformanceState().equalsIgnoreCase("NORMAL"))
							&& (performanceVO.getCollectorStatus() != null
									&& performanceVO.getCollectorStatus().equalsIgnoreCase("COLLECTING_DATA"))) {
						degradedDatabases.add(performanceVO);
					}
				}
			}

		}

		/*
		 * Se obtienen los id de los nodos de todas la BDs. Esto se debe convertir en
		 * catalogo
		 */
		List<DatabaseNodeVO> databaseNodes = null;
		databaseNodes = getDatabaseServers();

		/**
		 * Filtrar s�lo las bds alarmadas
		 * 
		 * 
		 */

		List<DatabaseNodeVO> degradedNodes = null;

		degradedNodes = new ArrayList<DatabaseNodeVO>();

		for (PerformanceVO performanceVO : degradedDatabases) {

			for (DatabaseNodeVO dbNode : databaseNodes) {

				if (performanceVO.getConfigId() == dbNode.getConfigId()) {

					degradedNodes.add(dbNode);
				}
			}

		}

		for (DatabaseNodeVO dBDegradedNode : degradedNodes) {

			List<DatabaseAlertVO> alertsByNodes = getHealthRulesViolations(dBDegradedNode.getId());

			for (DatabaseAlertVO databaseAlertVO : alertsByNodes) {
				System.out.println(":::::::::::::::" + databaseAlertVO.getDeepLinkUrl());
				System.out.println(":::::::::::::::" + databaseAlertVO.getSeverity());
				System.out.println(
						":::::::::::::::::::::::" + databaseAlertVO.getTriggeredEntityDefinition().getEntityType());
				System.out
						.println(":::::::::::::::::::::::" + databaseAlertVO.getTriggeredEntityDefinition().getName());
				System.out.println(":::::::::::::::" + databaseAlertVO.getName());
				System.out.println(":::::::::::::::" + databaseAlertVO.getDescription());

			}

		}

		/*
		 * Se consultan las alertas por databaseserverid
		 */

	}

}
