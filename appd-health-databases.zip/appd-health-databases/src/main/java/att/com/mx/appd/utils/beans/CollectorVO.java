package att.com.mx.appd.utils.beans;

public class CollectorVO {
	private int configId;
	private String collectorStatus;
	private CollectorConfigVO config;
	
	public CollectorVO(){
		
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	public String getCollectorStatus() {
		return collectorStatus;
	}

	public void setCollectorStatus(String collectorStatus) {
		this.collectorStatus = collectorStatus;
	}

	public CollectorConfigVO getConfig() {
		return config;
	}

	public void setConfig(CollectorConfigVO config) {
		this.config = config;
	}
	
	
}
