package att.com.mx.appd.service;

public interface AppDynamicsService {
	public void generateTemporaryAccessToken();
	public void getDatabaseAlarms();

}
